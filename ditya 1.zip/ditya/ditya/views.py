from django.http import HttpResponse
from django.shortcuts import render
from service.models import Contact

def homePage(request):
    return render(request,"index.html")

def aboutPage(request):
    return render(request,"about.html")

def contactPage(request):

    try:
          if request.method=="POST":
              f_name=request.POST['full_name']
              email=request.POST['email_id']
              subject=request.POST['subject']
              message=request.POST['message']
              data=Contact(full_name=f_name,email_id=email,subject=subject,message=message)
              data.save()
              
            #   print(f_name)
    except:
         pass    
    return render(request,'contact.html')

def projectPage(request):
    return render(request,"project.html")



def servicePage(request):
    return render(request,"service.html")

