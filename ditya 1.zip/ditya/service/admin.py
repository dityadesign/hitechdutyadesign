from django.contrib import admin
from service.models import Contact

class ContactAdmin(admin.ModelAdmin):
    list_display=("full_name","email_id","subject","message")


admin.site.register(Contact,ContactAdmin) 



